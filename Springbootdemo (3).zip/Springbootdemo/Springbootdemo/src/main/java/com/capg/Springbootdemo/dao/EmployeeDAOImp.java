package com.capg.Springbootdemo.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.Springbootdemo.model.Employee;

@Repository
@Transactional
public class EmployeeDAOImp implements EmployeeDAO{
    
    //define field for entityManager
    private EntityManager entityManager;
    
    //constructor to specify injections
    @Autowired
    public EmployeeDAOImp(EntityManager entityManager) {
        super();
        this.entityManager = entityManager;
    }
    @Override
    public Employee findById(int empid) {
        // using entityManager find an employee
        Employee emp=entityManager.find(Employee.class, empid);
        return null;
    }
    
    @Override
    public List<Employee> findAll() {
        // using entityManager create query to get all employees
        TypedQuery<Employee> query=entityManager.createQuery("select e from Employee e",Employee.class);
        List<Employee> list=query.getResultList();
        return list;
    }
    
    @Override
    public Employee save(Employee emp) {
        // TODO Auto-generated method stub
        entityManager.persist(emp);
        return entityManager.merge(emp);
    }
    
    @Override
    public boolean deleteById(int empid) {
        Employee emp =this.findById(empid);
        if(emp!=null) {
        entityManager.remove(empid);
        return true;
        }
        else
            return false;// TODO Auto-generated method stub
        
    }
    
//    @Override
//    public Employee updateById(int empid){
//       
//    	 Employee emp = this.findById(empid);       
//         if(emp!=null) {
//             emp.setCity("bangalore");
//        
//         
//             return emp;
//             }
//         else 
//             throw new RuntimeException("could not find the employee ");  
//  
//
//}
    
    } 