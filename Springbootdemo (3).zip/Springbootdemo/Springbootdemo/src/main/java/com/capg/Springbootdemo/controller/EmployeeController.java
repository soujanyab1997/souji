package com.capg.Springbootdemo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.Springbootdemo.model.Employee;
import com.capg.Springbootdemo.services.EmployeeService;

 


 

 

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class EmployeeController {
    /*@GetMapping(value="/hello")
    @ResponseBody
    public String sayHello() {
        System.out.println("saying hello");
        return "hi i am chitti speed 1tb memory 10 zeta byte version 2.0 reloaded uhuuuuu...";
    }*/
    
    private EmployeeService empService;
     @Autowired
     public EmployeeController(EmployeeService empService) {
         super();
         this.empService=empService;
         
     }
    // @CrossOrigin(origins="http://localhost:4200")
     @GetMapping(value="/employees")
  public List<Employee> getEmployees() {
      return empService.getSortedEmpList();
    
      
  }
//     @CrossOrigin(origins="http://localhost:4200")
     @PostMapping(value="/employees")
     public Employee createEmployee(@RequestBody Employee emp) {
        return empService.saveNewEmployee(emp);
         
     }
     
     
     @GetMapping("/employees/{empid}")
     public Employee getEmployee(@PathVariable int empid) {
         
        return empService.getEmp(empid);
          }
     
    // 
     @DeleteMapping("/employees/{empid}")
     
     public String removeEmployee(@PathVariable int empid) {
         
         Employee emp=empService.getEmp(empid);
         System.out.println(emp);
         if(emp!=null) {
         if(empService.removeEmployee(empid)) {
             return "Employee Deleted Successfully";
             
         }
         else {
             return "could not find the employee";
         }
         }
         else {
        	 return "not find ";
     
}
     
//         
//     @PutMapping(value="/employees/{empid}")
//     public Employee updateEmployee(@PathVariable int empid)
//     {
//         return empService.updateEmployee(empid);
//     }
     
     
}
}
 