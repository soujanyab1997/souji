package com.capg.Springbootdemo.dao;

import java.util.List;

import com.capg.Springbootdemo.model.Employee;

public interface EmployeeDAO {
	public Employee findById(int empid);
  
   public  List<Employee> findAll();
   public Employee save(Employee emp);
   public boolean deleteById(int empid);
   //public Employee updateById(int empid);
   
}