package com.capg.Springbootdemo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.Springbootdemo.dao.EmployeeDAO;
import com.capg.Springbootdemo.dao.EmployeeRepository;
import com.capg.Springbootdemo.model.Employee;

@Service
public class EmployeeService {
    private EmployeeRepository empRepo;
    
//    private EmployeeDAO empDAO;
//    
//    @Autowired
//    public EmployeeService(EmployeeDAO empdao) {
//        super();
//        this.empDAO = empdao;
//    }
    
   
        @Autowired
    	public EmployeeService(EmployeeRepository empRepo) {
		super();
		this.empRepo=empRepo;
		// TODO Auto-generated constructor stub
	}
        public List<Employee> getSortedEmpList() {
	// TODO Auto-generated method stub
//        List<Employee> empList = empDAO.findAll();
//        return empList;
        	List<Employee> empList=empRepo.findAll();
        	return empList;
   }
    public Employee saveNewEmployee(Employee emp) {
    return empRepo.save(emp);
    //	return empDAO.save(emp);
    }
    public Employee getEmp(int empid) {
    	Optional<Employee>empo= empRepo.findById(empid);
    	return empo.get();
    	//return empDAO.findById(empid);
    }
    public boolean removeEmployee(int empid) {
    	try {
    	empRepo.deleteById(empid);
    	return true;
    	}
    	catch(IllegalArgumentException e) {
    		return false;
    	}
    	//return empDAO.deleteById(empid);
    }
//    public Employee updateEmployee(int empid) {
//        return empDAO.updateById(empid);
//    }
}