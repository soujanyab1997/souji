package com.example.Springbootdemo;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
