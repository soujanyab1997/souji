package com.capg.dao;

 

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

 

import com.capg.model.Employee;

 

public class EmployeeDAO {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpaDemo");
     EntityManager manager=factory.createEntityManager();
    EntityTransaction tx =manager.getTransaction();
public void saveEmp(Employee emp ){
    
     tx.begin();
     manager.persist(emp);
     tx.commit();
}
//public void getEmployee(int employeeid){
//    Employee e=manager.find(Employee.class,101);
//    System.out.println(e);
//    
//    
//}
//public void removeEmployee(int employeeid){
//    Employee e=manager.find(Employee.class,employeeid);
//    tx.begin();
//    manager.remove(e);
//    tx.commit();
//}
//public void updateEmployee(int employeeid){
//    Employee e=manager.find(Employee.class,employeeid);
//    tx.begin();
//    e.seteName("ammu");
//    tx.commit();
//}
}
 