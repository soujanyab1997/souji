package com.capg.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	@Id
private int Employeeid;
@Override
	public String toString() {
		return "Employee [Employeeid=" + Employeeid + ", eName=" + eName + ", city=" + city + ", salary=" + salary
				+ "]";
	}
private String eName;
private String city;
private double salary;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}

public Employee(int employeeid, String eName, String city, double salary) {
	super();
	Employeeid = employeeid;
	this.eName = eName;
	this.city = city;
	this.salary = salary;
}

public int getEmployeeid() {
	return Employeeid;
}
public void setEmployeeid(int employeeid) {
	Employeeid = employeeid;
}
public String geteName() {
	return eName;
}
public void seteName(String eName) {
	this.eName = eName;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}

}
