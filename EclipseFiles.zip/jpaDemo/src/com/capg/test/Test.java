package com.capg.test;

import com.capg.dao.EmployeeDAO;
import com.capg.model.Employee;

public class Test {


    public static void main(String[] args) {
        // TODO Auto-generated method stub
 /*EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA_Demo1");
 EntityManager manager=factory.createEntityManager();
EntityTransaction tx =manager.getTransaction();*/
Employee emp=new Employee(103,"sjhkj","hd",20000.0);
EmployeeDAO edao=new EmployeeDAO();
edao.saveEmp(emp);
//edao.getEmployee(101);
 //edao.removeEmployee(103);
 //edao.updateEmployee(102);
 /*//tx.begin();
 manager.persist(emp1);
 tx.commit();*/
/*Employee e=manager.find(Employee.class,102);
System.out.println(e);
tx.begin();
manager.remove(e);
tx.commit();*/
 
    }

}

