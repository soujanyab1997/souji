package com.capg.dao;

 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

 

import com.capg.model.Book;
import com.capg.utils.DBConfig;

 

public class BookDAO {
    
    //insert
    public int insertBook(Book book) throws SQLException{
        
        Connection con=DBConfig.getConnection();
        
        String sql="INSERT INTO BOOK_TB VALUES(?, ?, ?)";
        PreparedStatement stmt=con.prepareStatement(sql);
        stmt.setInt(1, book.getBookId());
        stmt.setString(2,  book.getBookTitle());
        stmt.setString(3, book.getDescription());
        int result=stmt.executeUpdate();
        DBConfig.close(con);
        return result;
        
    }

 

}