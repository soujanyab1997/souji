package com.capg.model;

 

public class Book {
    
    private int book_id;
    private String book_title;
    private String book_desc;
    public Book() {
        super();
        // TODO Auto-generated constructor stub
    }
    public Book(int bookId, String bookTitle, String description) {
        super();
        this.book_id = bookId;
        this.book_title = bookTitle;
        this.book_desc = description;
    }
    public int getBookId() {
        return book_id;
    }
    public void setBookId(int bookId) {
        this.book_id = bookId;
    }
    public String getBookTitle() {
        return book_title;
    }
    public void setBookTitle(String bookTitle) {
        this.book_title = bookTitle;
    }
    public String getDescription() {
        return book_title;
    }
    public void setDescription(String description) {
        this.book_title = description;
    }
    
    

 

}
 