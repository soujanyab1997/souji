package com.capg.test;

 

import java.sql.SQLException;

 

import com.capg.dao.BookDAO;
import com.capg.model.Book;

 

public class Test {

 

    public static void main(String[] args) throws SQLException {
        // TODO Auto-generated method stub

 

        Book book=new Book(101, "Java", "Complete of Java");
        
        BookDAO bookDAO=new BookDAO();
        int rows=bookDAO.insertBook(book);
        if(rows>0)
            System.out.println("book inserted");
        else
            System.out.println("book not inserted");
    }

 

}