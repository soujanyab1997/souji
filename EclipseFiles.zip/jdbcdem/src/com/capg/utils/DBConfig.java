package com.capg.utils;

 


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

 

 

 

 

public class DBConfig {
    
    static{
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    public static Connection getConnection(){
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost/MYDB", "root", "root");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
        
    }

 

    public static void close(Connection con){
        try {
            con.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
 