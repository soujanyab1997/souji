package com.capg.SpringBootDemo1.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.SpringBootDemo1.DAO.EmployeeDAO;
import com.capg.SpringBootDemo1.Model.Employee;

@Service
public class EmployeeService {
    private EmployeeDAO employeeDAO;
    @Autowired
    public EmployeeService(EmployeeDAO employeeDAO) {
        super();
        this.employeeDAO = employeeDAO;
    }
    public List<Employee> getSortedEmpList(){
        List<Employee> empList=employeeDAO.findAll();
        return empList;
    }

 public Employee saveNewEmployee(Employee emp) {
	 
	 
	return employeeDAO.save(emp);
	 
 }
 public Employee getEmp(int empId) {
	 return employeeDAO.findById(empId);
 }
 public boolean removeEmployee(int empId) {
	 return employeeDAO.deleteById(empId);
 }

}
 
	

