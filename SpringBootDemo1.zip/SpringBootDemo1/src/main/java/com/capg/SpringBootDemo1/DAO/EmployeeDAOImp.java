package com.capg.SpringBootDemo1.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.SpringBootDemo1.Model.Employee;

@Repository
@Transactional
public class EmployeeDAOImp implements EmployeeDAO{
    
    //define field for entityManager
    private EntityManager entityManager;
    
    //constructor to specify injections
    @Autowired
    public EmployeeDAOImp(EntityManager entityManager) {
        super();
        this.entityManager = entityManager;
    }

 

    
    @Override
    public Employee findById(int empId) {
        // using entityManager find an employee
        Employee emp=entityManager.find(Employee.class, empId);
        return emp;
    }

 

    
    @Override
    public List<Employee> findAll() {
        // using entityManager create query to get all employees
    	TypedQuery<Employee> query=entityManager.createQuery("select e from Employee e",Employee.class);
    	List<Employee> list=query.getResultList();
    	return list;
    }




	@Override
	
	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		entityManager.persist(emp);
		return entityManager.merge(emp);
	}




	@Override
	public boolean deleteById(int empId) {
		Employee emp =this.findById(empId);
		if(emp!=null) {
		entityManager.remove(empId);
		return true;
		}
		else
			return false;// TODO Auto-generated method stub
		
	}
    
    

 

}