import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchMusicComponent } from './search-music/search-music.component';
import { HomeComponent } from './home/home.component';
import { ShowAlbumsComponent } from './show-albums/show-albums.component';
import { AddMusicComponent } from './add-music/add-music.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { MusicService } from './music.service';


@NgModule({
  declarations: [
    AppComponent,
    SearchMusicComponent,
    HomeComponent,
    ShowAlbumsComponent,
   AddMusicComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
   HttpClientModule,FormsModule
  ],
  providers: [MusicService],
  bootstrap: [AppComponent]
})
export class AppModule { }
