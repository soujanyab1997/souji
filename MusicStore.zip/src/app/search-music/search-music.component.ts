import { Component, OnInit } from '@angular/core';
import { Music } from '../music';
import { MusicService } from '../music.service';

@Component({
  selector: 'app-search-music',
  templateUrl: './search-music.component.html',
  styleUrls: ['./search-music.component.css']
})
export class SearchMusicComponent implements OnInit {
  musics:Music[];
  constructor(private musicService:MusicService) { }
  ngOnInit() {
  }
  search(data)
  {
    console.log(data.searchTerm);
    this.musics=this.musicService.getMusic().filter(mus=>mus.id==data.searchTerm);
    if(this.musics.length==0)
    {
      this.musics=this.musicService.getMusic().filter(mus=>mus.title==data.searchTerm);
    }
  }
}
