import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowAlbumsComponent } from './show-albums/show-albums.component';
import { HomeComponent } from './home/home.component';
import { SearchMusicComponent } from './search-music/search-music.component';
import { AddMusicComponent } from './add-music/add-music.component';


const routes: Routes = [
  {path:"show",component:ShowAlbumsComponent},
  {path:'',component:HomeComponent},
  {path:"search",component:SearchMusicComponent},
  {path:"add",component:AddMusicComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
