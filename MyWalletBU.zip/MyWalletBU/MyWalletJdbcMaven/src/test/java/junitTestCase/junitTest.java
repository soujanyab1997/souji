/**
 * 
 */
package junitTestCase;
import com.capgemini.bean.Customer;
import com.capgemini.dao.*;
import com.capgemini.exception.CustomerException;
import com.capgemini.util.dbConnection;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * @author bhawmish
 *
 */
public class junitTest {
	static DaoInterface dao=new DaoClass();
	String testname="bhawani";
	String phonenumber="7692812835";
	String accountnumber="8702913845";
	String testbalance="30000";

	@Test
	void test() throws CustomerException, SQLException, Exception {
	long accNo = 8702913845l;
	Connection con = null;

	PreparedStatement ps = null;
	ResultSet resultset = null;

	try {
		con = dbConnection.getConnection();
		ps = con.prepareStatement("select * from customer where accNo=" + accNo);
		resultset = ps.executeQuery();

		while (resultset.next()) {
			assertEquals(accountnumber,resultset.getString("accNo"));
			assertEquals(testname, resultset.getString("name"));
			assertEquals(testbalance, resultset.getString("balance"));
			assertEquals(phonenumber, resultset.getString("phoneNo"));
		}

	} catch (SQLException sqlException) {
		sqlException.printStackTrace();
		throw new CustomerException("Tehnical problem occured. Refer log");

	}

	finally {
		try {
			if (con != null) {
				resultset.close();
				ps.close();
				con.close();
			}
		} catch (SQLException e) {
			throw new CustomerException("Error in closing db connection");

		}
	}
}

	
	
	}

