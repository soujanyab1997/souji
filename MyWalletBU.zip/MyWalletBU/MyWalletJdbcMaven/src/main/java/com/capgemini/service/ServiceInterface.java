//Service class interface
package com.capgemini.service;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.bean.Customer;
import com.capgemini.exception.CustomerException;
public interface ServiceInterface {
	void getAccountDetails(long accNo) throws CustomerException, SQLException, Exception;

	void deposit(long accnotemp,double balance1) throws CustomerException;

	void withdraw(long accnotemp3,double balance2) throws CustomerException;

	void transfer(long accnotemp2, long accnotemp4, double balance3) throws CustomerException;

	void printTransaction() throws CustomerException;
	
}
