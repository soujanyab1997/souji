package com.capgemini.exception;

public class CustomerException extends Exception {
	public CustomerException(String message) 
	{		
		super(message);
	}
}
