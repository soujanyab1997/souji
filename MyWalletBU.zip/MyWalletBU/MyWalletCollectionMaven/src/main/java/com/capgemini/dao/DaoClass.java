//DAO class to declare methods
package com.capgemini.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.capgemini.bean.Customer;

public class DaoClass implements DaoInterface {
	static Customer c1=new Customer();
	static Map<Long,Customer> customers=new HashMap<Long,Customer>(); //declaring hash map to store values of customer
	ArrayList<String> mylist = new ArrayList<String>();  //array for transactions
	public boolean createCustomer(Customer customer) {
	c1=customer;
		customers.put(c1.getAccNo(), customer);
		return true;
	}
	
	/*************************************************************
	 * method to set account details (non-Javadoc)
	 * @see com.capgemini.dao.DaoInterface#getAccountDetails(long)
	 * method name:getAccountDetails
	 * return type:void
	 * argument type:long
	 */
	@Override
	public void getAccountDetails(long accNo) {
		// TODO Auto-generated method stub
		if(customers.containsKey(accNo)) {
			Set<Entry<Long,Customer>> set=customers.entrySet();     
			Iterator<Entry<Long,Customer>> itr=set.iterator();
			while(itr.hasNext()) {
				Map.Entry<Long, Customer> entry=(Map.Entry<Long, Customer>) itr.next();
				if(entry.getKey().equals(accNo)) {
					Customer c=entry.getValue();
					System.out.println("Account number: "+c.getAccNo()+"\n Name: "+c.getName()+"\n phone number: "+c.getPhoneNo()+"\n Balance amount: "+c.getBalance());
				}
			}
		}
	}
	
	/************************************************************
	 * method to deposit (non-Javadoc)
	 * @see com.capgemini.dao.DaoInterface#deposit(long,double)
	 * method name:deposit
	 * return type:void
	 * argument type:long,double
	 */
	@Override
	public void deposit(long accnotemp, double balance1) {
		// TODO Auto-generated method stub
		Set fnd=customers.entrySet();
		Iterator it=fnd.iterator();
		double balanceD=0d;
		while(it.hasNext()) {
			Map.Entry<Long, Customer>entry=(Map.Entry<Long, Customer>)it.next();
			if(entry.getKey()==accnotemp) {
				balanceD=entry.getValue().getBalance()+balance1;
				entry.getValue().setBalance(balanceD);
				
			}
		}
		mylist.add(balance1 + " Deposited to "+accnotemp);
		//return balanceD;
	}
	
	/************************************************************
	 * method to withdraw (non-Javadoc)
	 * @see com.capgemini.dao.DaoInterface#withdraw(long,double)
	 * method name:withdraw
	 * return type:void
	 * argument type:long,double
	 */
	@Override
	public void withdraw(long accnotemp3,double balance2) {
		// TODO Auto-generated method stub
		Set fnd=customers.entrySet();
		Iterator it=fnd.iterator();
		double balanceW=0d;
		while(it.hasNext()) {
			Map.Entry<Long, Customer>entry=(Map.Entry<Long, Customer>)it.next();
			if(entry.getKey()==accnotemp3) {
				balanceW=entry.getValue().getBalance()-balance2;
				entry.getValue().setBalance(balanceW);
			}
		}
		mylist.add(balance2 + " Withdrawn from "+accnotemp3);
		//return balanceW;
	}
	
	/************************************************************
	 * method to transfer (non-Javadoc)
	 * @see com.capgemini.dao.DaoInterface#transfer(long,long,double)
	 * method name:transfer
	 * return type:void
	 * argument type:long,long,double
	 */
	@Override
	public void transfer(long accnotemp2, long accnotemp4, double balance3) {
		// TODO Auto-generated method stub
		Set fnd=customers.entrySet();
		Iterator it=fnd.iterator();
		double balanceT1=0d;
		double balanceT2=0d;
		while(it.hasNext()) {
			Map.Entry<Long, Customer>entry=(Map.Entry<Long, Customer>)it.next();
			if(entry.getKey()==accnotemp2) {//acctemp2 is account to be credited to
				balanceT1=entry.getValue().getBalance()+balance3;
				entry.getValue().setBalance(balanceT1);
			}
			if(entry.getKey()==accnotemp4) {//acctemp4 is account to be credited from
				balanceT2=entry.getValue().getBalance()-balance3;
				entry.getValue().setBalance(balanceT2);
		}
	}
		mylist.add(balance3 + " Transferred from "+accnotemp4+" to "+accnotemp2);
	}
	
	/************************************************************
	 * method to printTransaction (non-Javadoc)
	 * @see com.capgemini.dao.DaoInterface#printTransaction()
	 * method name:printTransaction
	 * return type:void
	 * argument type:void
	 */
	@Override
	public void printTransaction() {
		for (String string : mylist) {
			System.out.println(string);
		}
			
		// TODO Auto-generated method stub	
	}
	}
	
