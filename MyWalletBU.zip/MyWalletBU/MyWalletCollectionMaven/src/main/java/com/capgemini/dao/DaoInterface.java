//DAO class interface
package com.capgemini.dao;

import com.capgemini.bean.Customer;

public interface DaoInterface {
void getAccountDetails(long accNo);

void deposit(long accnotemp, double balance1);

void withdraw(long accnotemp3,double balance2);

void printTransaction();

boolean createCustomer(Customer c);

void transfer(long accnotemp2, long accnotemp4, double balance3);

}
