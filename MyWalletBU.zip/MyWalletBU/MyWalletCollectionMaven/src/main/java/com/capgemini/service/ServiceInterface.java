//Service class interface
package com.capgemini.service;
import com.capgemini.bean.Customer;
public interface ServiceInterface {
	void getAccountDetails(long accNo);

	void deposit(long accnotemp,double balance1);

	void withdraw(long accnotemp3,double balance2);

	void transfer(long accnotemp2, long accnotemp4, double balance3);

	void printTransaction();
	
}
