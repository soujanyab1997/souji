//Starter class to take input and show output
package com.capgemini.ui;
import java.io.IOException;
import java.util.Scanner;

import com.capgemini.bean.Customer;
import com.capgemini.service.*;
public class Main {
public static void main(String[] args){

	char choice;
	Scanner sc=new Scanner(System.in);
	ServiceInterface serviceC=new ServiceClass();
	System.out.println("================My Wallet Application===============");
	do {
	System.out.println("Make a choice:");
	System.out.println("1: Create account \n 2: Show Balance \n 3: Deposit \n 4: Withdraw \n 5: Fund Transfer \n 6: Print Transaction \n 7: Exit");
	
	int inp=sc.nextInt();
	sc.nextLine();
	switch(inp) {
	case 1:
	    Customer c1=new Customer();
		System.out.println("Enter name: ");
		String name=sc.nextLine();
		
		if(ServiceClass.stringValidator(name, ServiceClass.namevalidator)) {
		c1.setName(name);
		}
		else {
			System.out.println("Invalid name");
			break;
		}
			System.out.println("Enter phone number: ");
		long phoneNo=sc.nextLong();
		String s1=Long.toString(phoneNo);
		if(ServiceClass.stringValidator(s1, ServiceClass.mobilenovalidator)) {
			c1.setPhoneNo(phoneNo);
			}
			else {
				System.out.println("Invalid phone number");
				break;
			}
		System.out.println("Enter balance amount: ");
		double balance=sc.nextDouble();
		c1.setBalance(balance);
		long accNo=1010101010l+phoneNo;
		c1.setAccNo(accNo);
		if(ServiceClass.createCustomer(c1)==true) {
			System.out.println("Account successfully created");
		}
		System.out.println("Generated account number: "+accNo);
		break;
	case 2:
		System.out.println("Enter the account number of customer: ");
		long accNum=sc.nextLong();
		serviceC.getAccountDetails(accNum);
		break;
	case 3:
		System.out.println("Enter account number to be deposited in: ");
		long accnotemp=sc.nextLong();
		System.out.println("Enter deposit amount: ");
		double balance1=sc.nextDouble();
		serviceC.deposit(accnotemp,balance1);
		System.out.println(balance1+ " Deposited");
		break;
	case 4:
		System.out.println("Enter account number to be withdrawn from: ");
		long accnotemp3=sc.nextLong();
		System.out.println("Enter amount to be withdrawn: ");
		double balance2=sc.nextDouble();
		serviceC.withdraw(accnotemp3,balance2);
		System.out.println(balance2+ " withdrawn");
		break;
	case 5:
		System.out.println("Enter account in which amount is to be transferred: ");
		long accnotemp2=sc.nextLong();
		System.out.println("Enter account to be transferred from: ");
		long accnotemp4=sc.nextLong();
		System.out.println("Enter amount to be transferred: ");
		double balance3=sc.nextDouble();
		serviceC.transfer(accnotemp2,accnotemp4,balance3);
		System.out.println(balance3+" transferred to "+accnotemp2);
		break;
	case 6:
		serviceC.printTransaction();
		break;
	case 7:
		System.out.println("Exiting....");
		System.exit(0);
	}
	System.out.println("do you want to continue (y/n):");
	choice=sc.next().charAt(0);
	}while(choice != 'n');
	sc.close();
	}
	
}
