var greet = function () {
    console.log('Hello world!');
};
greet();
