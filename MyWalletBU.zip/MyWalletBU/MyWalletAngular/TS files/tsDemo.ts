const greet = () => {
    console.log('Hello world!')
  }
  
  greet()