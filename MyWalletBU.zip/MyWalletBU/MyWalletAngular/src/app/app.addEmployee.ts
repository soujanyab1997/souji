import { Component, OnInit } from "@angular/core";
import {EmployeeService} from './app.employeeService';
import { Account } from "./models/Account";
@Component({
    selector:'add-emp',
    templateUrl:'addemployee.html'
})


export class AddEmployeeComponent implements OnInit{
    
    id:number;
    phoneno:string;
    accholdername:string;
    balance:number;
    acc:Account
    constructor(private service:EmployeeService){}
    ngOnInit(){}
  
    save()
    {
       
        var  account:Account=new Account(this.id,this.phoneno,this.accholdername,this.balance);
        console.log(account);
        this.service.createAccount(account).subscribe(
            res=>{
                this.acc=res
            }
        );     
    }   
    ch=false;
    change(){
        this.ch=true;
    } 
}