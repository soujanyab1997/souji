import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-listallemployee',
  templateUrl: './listallemployee.component.html',
  styleUrls: ['./listallemployee.component.css']
})
export class ListallemployeeComponent implements OnInit {
  empId: number;
  empName: string;
  empEmail: string;
  empPhone: number;
  ser: EmployeeService = new EmployeeService();
  listarr: Employee[] = [];

  constructor() { }

  ngOnInit() {
    this.listarr = this.ser.listEmpService();

  }

  update(i) {
    this.empId = this.listarr[i].id;
    this.empName = this.listarr[i].name;
    this.empEmail = this.listarr[i].email;
    this.empPhone = this.listarr[i].phone;
  }

  delete(i) {
    alert('This Record will be Deleted');
    this.ser.delete(i);
  }

  empUpdate(val) {
    this.listarr = this.ser.empUpdateService(val);
    }
}
