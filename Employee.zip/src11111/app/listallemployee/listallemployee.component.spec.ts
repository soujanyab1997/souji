import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListallemployeeComponent } from './listallemployee.component';

describe('ListallemployeeComponent', () => {
  let component: ListallemployeeComponent;
  let fixture: ComponentFixture<ListallemployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListallemployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListallemployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
