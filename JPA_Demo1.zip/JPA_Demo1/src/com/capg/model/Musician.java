package com.capg.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.eclipse.persistence.jpa.config.Cascade;

@Entity
public class Musician {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long musicianId;
	private String name;
	@OneToMany(cascade=CascadeType.PERSIST,fetch=FetchType.EAGER)
	private List<Song>songs=new ArrayList<>();
	public Musician() {
		super();
	}
	public Musician(String name, List<Song> songs) {
		super();
		this.name = name;
		this.songs = songs;
	}
	public long getMusicianId() {
		return musicianId;
	}
	public void setMusicianId(long musicianId) {
		this.musicianId = musicianId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Song> getSongs() {
		return songs;
	}
	public void setSongs(List<Song> songs) {
		this.songs = songs;
	}
	@Override
	public String toString() {
		return "Musician [musicianId=" + musicianId + ", name=" + name + ", songs=" + songs + "]";
	}
	
	
	

}
