package com.capg.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Employee {
	@Id
	//@Column(name="eemid")
	@GeneratedValue(strategy=GenerationType.AUTO)
private int empId;
private String eName;
private String city;
private String salary;
@OneToOne(cascade=CascadeType.PERSIST)
private Department dept;
public Employee() {
	super();
}

public Employee(String eName, String city, String salary) {
	super();
	this.eName = eName;
	this.city = city;
	this.salary = salary;
}

public Employee(int empId, String eName, String city, String salary) {
	super();
	this.empId = empId;
	this.eName = eName;
	this.city = city;
	this.salary = salary;
}

public Employee(String eName, String city, String salary, Department dept) {
	super();
	this.eName = eName;
	this.city = city;
	this.salary = salary;
	this.dept = dept;
}

public Employee(int empId, String eName, String city, String salary, Department dept) {
	super();
	this.empId = empId;
	this.eName = eName;
	this.city = city;
	this.salary = salary;
	this.dept = dept;
}

public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String geteName() {
	return eName;
}
public void seteName(String eName) {
	this.eName = eName;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getSalary() {
	return salary;
}
public void setSalary(String salary) {
	this.salary = salary;
}

public Department getDept() {
	return dept;
}

public void setDept(Department dept) {
	this.dept = dept;
}

@Override
public String toString() {
	return "Employee [empId=" + empId + ", eName=" + eName + ", city=" + city + ", salary=" + salary + ", dept=" + dept
			+ "]";
}



}
