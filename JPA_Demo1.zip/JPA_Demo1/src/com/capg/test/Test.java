package com.capg.test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capg.dao.EmployeeDAO;
import com.capg.model.Department;
import com.capg.model.Employee;
import com.capg.model.Musician;
import com.capg.model.Song;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA_Demo1");
 EntityManager manager=factory.createEntityManager();
EntityTransaction tx =manager.getTransaction();
// List<Song> songs =new ArrayList<>();
//songs.add(new Song("s1"));
//songs.add(new Song("s2"));
//songs.add(new Song("s3"));
//Musician musician=new Musician("lahari",songs);
//
//tx.begin();
//manager.persist(musician);
//tx.commit();
Musician m=manager.find(Musician.class, 201L);
System.out.println(m.getSongs());
 
	}

}
