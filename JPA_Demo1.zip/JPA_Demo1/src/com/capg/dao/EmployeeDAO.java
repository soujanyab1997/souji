package com.capg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capg.model.Employee;

public class EmployeeDAO {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA_Demo1");
	 EntityManager manager=factory.createEntityManager();
	EntityTransaction tx =manager.getTransaction();
public void saveEmp(Employee emp ){
	
	 tx.begin();
	 manager.persist(emp);
	 tx.commit();
}
public void getEmployee(int empId){
	Employee e=manager.find(Employee.class,101);
	System.out.println(e);
	
	
}
public void removeEmployee(int empId){
	Employee e=manager.find(Employee.class,empId);
	tx.begin();
	manager.remove(e);
	tx.commit();
}
public void updateEmployee(int empId){
	Employee e=manager.find(Employee.class,empId);
	tx.begin();
	e.seteName("ammu");
	tx.commit();
}
public List<Employee> display(){
    //Query query = manager.createQuery("Select e FROM Employee e");
    Query query = manager.createQuery(" FROM Employee e",Employee.class);
    List<Employee> result = query.getResultList();
    return result;
}
}
