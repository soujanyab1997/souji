import { CourseFilterPipe } from './course-filter.pipe';

describe('CourseFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CourseFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
