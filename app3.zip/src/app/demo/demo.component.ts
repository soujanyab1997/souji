import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
isActive:boolean;

myNum="5"
bordered={
  'border':'1px solid brown',
  'background':'bisque',
  'padding':'1px'
}
  constructor() { }

  ngOnInit() {
    this.isActive=true;
  }
handle(){
  this.isActive=this.isActive?false:true;
}
}
