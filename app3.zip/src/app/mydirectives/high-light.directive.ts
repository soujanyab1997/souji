import { Directive, ElementRef, Renderer2, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appHighLight]'
})
export class HighLightDirective {
  @HostBinding('style.backgroundColor')
private bgcolor:string='pink';
  constructor(private eleRef:ElementRef,private renderer:Renderer2) { 
    //console.log('highlight directive is applied',this.eleRef.nativeElement)
   // this.eleRef.nativeElement.style.background='orange'
  // this.renderer.setStyle(this.eleRef.nativeElement,'background','yellow')

  }
  @HostListener('mouseover')
  changeColorOnMouseOver(){
    this.bgcolor='blue'
  }
  @HostListener('mouseout')
  changeColorOnMouseOut(){
  this.bgcolor='orange'
}
}