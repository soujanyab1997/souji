import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
private registerForm:FormGroup;
  constructor() { 

  }

  ngOnInit() {
    this.registerForm=new FormGroup({
      username:new FormControl('',[Validators.required, Validators.minLength(4),this.sholdNotSpace]),
      password:new FormControl('',[Validators.required, Validators.minLength(4),this.sholdNotSpace])
    });
  }
  sholdNotSpace(control:AbstractControl):ValidationErrors|null{
const value = control.value;
if(value.indexOf(' ')!=-1){
return {sholdNotSpace:true}
}
return null;
  }
  register(){
    console.log('submit is clicked')
    console.log(this.registerForm)
  }

}
