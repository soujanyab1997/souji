export class Post{
    private uid:number;
    private id:any;
    static  title:string;
    private body:string;

    
}