import { Component, OnInit } from '@angular/core';
import { Post } from './post.module';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
private postsData:Post[]=[];
  constructor(private http:HttpClient,private router:Router) { }

  ngOnInit() {
    this.http.get<Post[]>('https://jsonplaceholder.typicode.com/posts')//to construct HttpGET request ,it makes asynchronous request its nonblocking
    .subscribe(
      (response:Post[])=>{
        console.log('response received from server')
        console.log(response)
        this.postsData=response;
      },
      (error)=>{
        console.log('error')
        console.log(error);
      }
    )
    }
    

    deletePost(Post) {
      this.http.delete('https://jsonplaceholder.typicode.com/posts' + '/' + Post.id)
       .subscribe(
       (response)=> {
      console.log('Deleted the request successfully')
      const index=this.postsData.indexOf(Post);
      this.postsData.splice(index,1);
       },
       (error)=> {
      console.log(error)
       }
       )
      }
UpdatePost(Post)
      {
     Post.title="upate title ";
     this.http.patch<Post>('https://jsonplaceholder.typicode.com/posts' + '/' + Post.id,Post)
      .subscribe(
      (response)=>{
     const index = this.postsData.indexOf(Post);
     this.postsData[index]= response;
      
      
      },
      (error)=>{
     console.log('error',error);
      }
      )
      
      }
}
