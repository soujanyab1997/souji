import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
private companyName:string;
private imageUrl:string
  constructor() {}
  
  ngOnInit() {
    this.companyName='capgemini'
  this.imageUrl="assets/souji.jpg"
    setTimeout(()=>{this.companyName='lahariii'
  },6000)
  }
handleclick(){
  console.log("SOUJANYA")
}
}
