import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
private courses:any[];
  constructor() { }

  ngOnInit() {
    this.courses=[{cid:10,cname:'java',duration:'5days',fees:100.0}
    ,{cid:20,cname:'angukar',duration:'5days',fees:100.0}
    ,{cid:30,cname:'typescript',duration:'5days',fees:100.0}
    ,{cid:40,cname:'gahag',duration:'5days',fees:100.0}

  ];
  }
handleaddcourse(){
  const newcourse1={cid:101,cname:'spring',duration:'6 days',fees:10.0}
  this.courses.push(newcourse1)
  const newcourse={cid:101,cname:'soijjg',duration:'100 days',fees:10.0}
  this.courses.push(newcourse)
}

}
