import { Component, OnInit } from '@angular/core';
import {Book} from '../mobile';

import { BookService } from '../book.service';
@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  bookData:Book[];
  // searchedData:Book[];
  searchedId:any;
  searchedId2:any;
  searchedId3:any;
  searchedId4:any;
  searchedId5:any;


  flag = 0;

  constructor(private _bookservice:BookService){

  }
  ngOnInit(){
      this._bookservice.getAllBookDetail().
      subscribe((data:Book[])=>{
          this.bookData=data;
          console.log("");
      });
  }


 
}
