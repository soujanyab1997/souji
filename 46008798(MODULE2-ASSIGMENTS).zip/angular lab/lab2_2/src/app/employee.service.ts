import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { employee } from './employee';



@Injectable({
  providedIn: 'root'
})
export class EmployeeService {


constructor(private http: HttpClient) { }
 
public getEmployee() {
 // return  this.http.get<employee[]>('/assets/employeelist.json') 
 return this.http.get<employee[]>('/assets/employeelist.json')
}
}
