import { Component, OnInit } from '@angular/core';
import { employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  empllist:employee[]=[];

  constructor(private employeeservice:EmployeeService) { }

  ngOnInit() {
    this.employeeservice.getEmployee()
    .subscribe(
      (data)=>{
        this.empllist=data;
      console.log('employeelist=',this.empllist);
      },
      error=>console.log('getting error')
    )
  }
  idSort(){
    this.empllist.sort(function(a,b)
    {
        return a.empId - b.empId;
    });
    
}

nameSort()
{
    this.empllist.sort(function(a,b)
{
    if(a.empName < b.empName)
    return -1;
    else
    return 1;
})
}

salSort()
{
    this.empllist.sort(function(a,b)
    {
        return a.empSal - b.empSal;
    });
    
}

depSort()
{
    this.empllist.sort(function(a,b)
{
    if(a.empDep < b.empDep)
    return -1;
    else
    return 1;
})
}
   

}
