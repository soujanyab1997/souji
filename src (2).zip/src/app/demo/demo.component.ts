import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
  isActive:boolean
  bordered={'border':'1px solid brown','background':'bisque','padding':'1px'}
  mynum=1;

  constructor() { }

  ngOnInit() {
    this.isActive=false;
  }
  handleClick(){
    this.isActive=this.isActive?false:true;
  }

}
