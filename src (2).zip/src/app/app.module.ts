import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form/login-form.component';
    

import { FormsModule, ReactiveFormsModule } from'@angular/forms';
import { RegisterComponent } from './register/register.component';
import { DemoComponent } from './demo/demo.component';
import { HighLightDirective } from './mydirectives/high-light.directive';
import { CoursesComponent } from './courses/courses.component';
import { ShortenPipe } from './mypipes/shorten.pipe';
import { CourseFilterPipe } from './mypipes/course-filter.pipe';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { Routes, RouterModule } from '@angular/router';
import { PostComponent } from './post/post.component';
import { HttpClientModule} from '@angular/common/http';
import { PostFormComponent } from './post-form/post-form.component';
const appRoutes:Routes =[
  { path: '', component:HomeComponent},
  { path: 'courses', component:CoursesComponent},
  { path: 'login', component:LoginFormComponent},
  { path: 'register', component:RegisterComponent},
  { path: 'posts' , component:PostComponent},
  { path:'postform',component:PostFormComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    LoginFormComponent,
    RegisterComponent,
    DemoComponent,
    HighLightDirective,
    CoursesComponent,
    ShortenPipe,
    CourseFilterPipe,
    HomeComponent,
    NavbarComponent,
    PostComponent,
    PostFormComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
   HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
