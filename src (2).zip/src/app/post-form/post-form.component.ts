import { Component, OnInit } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { FormGroup, FormControl } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-post-form',
  templateUrl: './post-form.component.html',
  styleUrls: ['./post-form.component.css']
})
export class PostFormComponent implements OnInit {
private postform:FormGroup;
  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.postform=new FormGroup({
      PostTitle:new FormControl(''),
      UserId: new FormControl(''),
      Body: new FormControl('')
    
    })
  }
  addPost(){
//this.http.post('')
//console.log(this.postform.value);
this.http.post('https://jsonplaceholder.typicode.com/posts',this.postform.value)
 .subscribe(
 (response)=> {
 console.log('response received from server...')
 console.log(response)
 }
 ) 

}
}
