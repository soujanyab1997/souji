import { Directive, ElementRef, Renderer2, HostBinding, HostListener } from '@angular/core';
import { Hosted } from '../../../node_modules/protractor/built/driverProviders';

@Directive({
  selector: '[appHighLight]'
})
export class HighLightDirective {
  @HostBinding('style.backgroundColor')
   private bgColor:string='orange'

  //constructor(private eleRef:ElementRef,private renderer:Renderer2) {
   // console.log('applied',this.eleRef.nativeElement)
    //this.eleRef.nativeElement.style.background="yellow"
   // this.renderer.setStyle(this.eleRef.nativeElement,'background','pink')

   //}
   @HostListener('mouseover')
   changeColorOnMouseOver(){
     this.bgColor='pink'
   }
   @HostListener('mouseout')
   changeColorOnMouseOut(){
    this.bgColor='orange'
  }
}
