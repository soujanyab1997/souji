import { Component, OnInit } from '@angular/core';
import { Post } from '../model/post.model';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  
private postsData:Post[] =[];
  constructor(private http:HttpClient, private router:Router) { }

  ngOnInit() {
    this.http.get<Post[]>('https://jsonplaceholder.typicode.com/posts')
    .subscribe(
      (response:Post[])=>{
        
        console.log("response received ")
        console.log(response)
        this.postsData =response;
      },
      (error)=>{
        console.log('Error from server',error)
      }
    )
  }
  addNewPost(){
this.router.navigate(['/postform'])
  }
  deletePost(Post){
    this.http.delete<Post>('https://jsonplaceholder.typicode.com/posts'+'/'+Post.id)
    .subscribe(
      (response)=>{
        console.log("response received")
        
        const index=this.postsData.indexOf(Post)
        this.postsData.splice(index,1)
      }
     
    )
  }
  updatePost(Post){
    Post.title="upate title "
this.http.patch<Post>('https://jsonplaceholder.typicode.com/posts' + '/' + Post.id,Post)
 .subscribe(
 (response)=>{
const index = this.postsData.indexOf(Post)
this.postsData[index]= response;
 
 
 
  }


}
