import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {
private loginForm:FormGroup
  constructor() { }

  ngOnInit() {
    this.loginForm=new FormGroup({
      username:new FormControl('',[Validators.required, Validators.minLength(4),this.shouldNotContainSpace]),
      password:new FormControl('',[Validators.required,Validators.minLength(4)]),
      name:new FormControl()
    });
  }
  shouldNotContainSpace(control:AbstractControl):ValidationErrors|null{
 const value=control.value;
 if(value.indexOf(' ')!=-1){
   return{shouldNotContainSpace:true}
 }
 return null;
  }
login(){
  console.log('submit is clicked....')
  console.log(this.loginForm);
}
}
