package com.capgemini.bank.Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;

public interface BankApplicationDAO {
	static List<Transaction> printTransaction = new ArrayList<>();
	Map<Integer, Customer> customerList = new HashMap<>();
	public int createAccount(Customer customer);
	public double showBalance(int accountno);
	List<Transaction> deposit(int accountno, double amount);
	List<Transaction> withdraw(int accountno, double amount);
	List<Transaction> fundTransfer(int sourceAccountNo,int destinationAccountNo,double amount);
	List<Transaction> printTransactions(int accountno);
}
