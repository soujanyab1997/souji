package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exceptions.BankException;

public interface BankApplicationService {
	public int createAccount(Customer customer) throws BankException;
	public double showBalance(int accountno) throws BankException;
	List<Transaction> deposit(int accountno, double amount) throws BankException;
	List<Transaction> withdraw(int accountno, double amount) throws BankException;
	List<Transaction> fundTransfer(int sourceAccountno, int destinationAccountNo, double amount) throws BankException;
	List<Transaction> printTransactions(int accountno) throws BankException;
	public boolean isNameValid(String name) throws BankException;
	public boolean isMailValid(String mail) throws BankException;
	public boolean isMobileValid(String mobile) throws BankException;
	public boolean isAddressValid(String address) throws BankException;
}
