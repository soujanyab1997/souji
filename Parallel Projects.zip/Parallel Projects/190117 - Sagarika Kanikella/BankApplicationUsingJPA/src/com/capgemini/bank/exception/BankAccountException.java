package com.capgemini.bank.exception;

public class BankAccountException extends Exception{

	public BankAccountException(String message) {
		super(message);
	}
}
