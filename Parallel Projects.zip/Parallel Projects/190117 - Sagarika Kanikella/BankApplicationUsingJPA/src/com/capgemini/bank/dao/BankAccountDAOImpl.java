package com.capgemini.bank.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.bank.bean.AccountDetails;
import com.capgemini.bank.bean.CustomerDetails;
import com.capgemini.bank.bean.TransactionDetails;
import com.capgemini.bank.exception.BankAccountException;

public class BankAccountDAOImpl implements BankAccountDAO {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager manager = factory.createEntityManager();

	@Override
	public int createAccount(CustomerDetails customer, double amount) throws BankAccountException {
		manager.getTransaction().begin();
		Query query = manager.createNativeQuery("select accseq.nextval from dual");
		int accountNo = query.getFirstResult();
		AccountDetails account = new AccountDetails();
		account.setAccountNo(accountNo);
		account.setBalance(amount);
		manager.persist(account);
		// System.out.println(account);
		Query query1 = manager.createNativeQuery("select transseq.nextval from dual");
		int transId = query1.getFirstResult();
		TransactionDetails transaction = new TransactionDetails();
		transaction.setTransactionNo(transId);
		transaction.setTransactionMode("credit");
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		transaction.setTransactionDate(date);
		transaction.setAccountNo(account.getAccountNo());
		transaction.setAmount(amount);
		manager.persist(transaction);
		// System.out.println(transaction);
		Query query2 = manager.createNativeQuery("select custseq.nextval from dual");
		int custId = query2.getFirstResult();
		customer.setCustomerId(custId);
		customer.setAccountNo(account.getAccountNo());
		customer.setTransactionNo(transaction.getTransactionNo());
		manager.persist(customer);
		manager.getTransaction().commit();

		return account.getAccountNo();
	}

	@Override
	public double showBalance(int accountNo) throws BankAccountException {
		manager.getTransaction().begin();
		AccountDetails account = manager.find(AccountDetails.class, accountNo);
		manager.getTransaction().commit();

		return account.getBalance();
	}

	@Override
	public List<TransactionDetails> deposit(int accountNo, double amount) throws BankAccountException {
		manager.getTransaction().begin();
		AccountDetails account = manager.find(AccountDetails.class, accountNo);
		double balance = account.getBalance();
		balance += amount;
		account.setBalance(balance);
		manager.merge(account);
		Query query = manager.createNativeQuery("select transseq.nextval from dual");
		int transId = query.getFirstResult();
		TransactionDetails transaction = new TransactionDetails();
		transaction.setTransactionNo(transId);
		transaction.setTransactionMode("credit");
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		transaction.setTransactionDate(date);
		transaction.setAccountNo(accountNo);
		transaction.setAmount(amount);
		List<TransactionDetails> transactionList = new ArrayList<>();
		transactionList.add(transaction);
		manager.persist(transaction);
		manager.getTransaction().commit();

		return transactionList;
	}

	@Override
	public List<TransactionDetails> withdraw(int accountNo, double amount) throws BankAccountException {

		List<TransactionDetails> transactionList = new ArrayList<>();
		manager.getTransaction().begin();
		AccountDetails account = manager.find(AccountDetails.class, accountNo);
		double balance = account.getBalance();
		try {
			if (amount > balance) {
				throw new BankAccountException("Insufficient balance. Withdraw cannot be done!! \n");
			} else {
				balance -= amount;
				account.setBalance(balance);
				manager.merge(account);
				Query query = manager.createNativeQuery("select transseq.nextval from dual");
				int transId = query.getFirstResult();
				TransactionDetails transaction = new TransactionDetails();
				transaction.setTransactionNo(transId);
				transaction.setTransactionMode("debit");
				long millis = System.currentTimeMillis();
				java.sql.Date date = new java.sql.Date(millis);
				transaction.setTransactionDate(date);
				transaction.setAccountNo(accountNo);
				transaction.setAmount(amount);

				transactionList.add(transaction);
				manager.persist(transaction);

			}
		} catch (BankAccountException e) {
			System.out.println(e.getMessage());
		}
		manager.getTransaction().commit();
		return transactionList;
	}

	@Override
	public List<TransactionDetails> fundTransfer(int sourceAccount, int destinationAccount, double amount)
			throws BankAccountException {
		List<TransactionDetails> transactionList = new ArrayList<>();
		manager.getTransaction().begin();
		AccountDetails source = manager.find(AccountDetails.class, sourceAccount);
		double sourceBalance = 0;
		try {
			if (sourceBalance < amount) {
				throw new BankAccountException("Insufficient balance. Withdraw cannot be done!! \n");
			} else {
				sourceBalance = source.getBalance() - amount;
				source.setBalance(sourceBalance);
				manager.merge(source);
				AccountDetails destination = manager.find(AccountDetails.class, destinationAccount);
				double destinationBalance = destination.getBalance() + amount;
				destination.setBalance(destinationBalance);
				manager.merge(destination);
				Query query = manager.createNativeQuery("select transseq.nextval from dual");
				int transId = query.getFirstResult();
				TransactionDetails transaction = new TransactionDetails();
				transaction.setTransactionNo(transId);
				transaction.setTransactionMode("debit");
				long millis = System.currentTimeMillis();
				java.sql.Date date = new java.sql.Date(millis);
				transaction.setTransactionDate(date);
				transaction.setAccountNo(sourceAccount);
				transaction.setAmount(amount);

				transactionList.add(transaction);
				manager.persist(transaction);

				Query desquery = manager.createNativeQuery("select transseq.nextval from dual");
				int destransId = desquery.getFirstResult();
				TransactionDetails destransaction = new TransactionDetails();
				destransaction.setTransactionNo(destransId);
				destransaction.setTransactionMode("credit");
				long desmillis = System.currentTimeMillis();
				java.sql.Date desdate = new java.sql.Date(desmillis);
				destransaction.setTransactionDate(desdate);
				destransaction.setAccountNo(destinationAccount);
				destransaction.setAmount(amount);
				transactionList.add(destransaction);
				manager.persist(destransaction);
				manager.getTransaction().commit();
			}
		} catch (BankAccountException e) {
			System.out.println(e.getMessage());
		}
		manager.getTransaction().commit();
		return transactionList;
	}

	@Override
	public List<TransactionDetails> PrintTransaction(int accountNo) throws BankAccountException {
		List<TransactionDetails> transactionList = new ArrayList<>();
		Query query = manager.createQuery("select trans from TransactionDetails trans where accountno=:num");
		query.setParameter("num", accountNo);
		transactionList = query.getResultList();
		return transactionList;
	}
}
