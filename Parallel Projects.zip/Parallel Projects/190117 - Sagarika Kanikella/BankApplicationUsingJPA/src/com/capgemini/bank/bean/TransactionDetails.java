package com.capgemini.bank.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "transseq",initialValue = 110,allocationSize = 1)
public class TransactionDetails {

	@Id
	@GeneratedValue(generator = "transseq",strategy = GenerationType.SEQUENCE)
	private int transactionNo;
	private String transactionMode;
	private Date transactionDate;
	private int accountNo;
	private double amount;
	public TransactionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionDetails(int transactionNo, String transactionMode, Date transactionDate, int accountNo,
			double amount) {
		super();
		this.transactionNo = transactionNo;
		this.transactionMode = transactionMode;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.amount = amount;
	}
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public String getTransactionMode() {
		return transactionMode;
	}
	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "TransactionDetails [transactionNo=" + transactionNo + ", transactionMode=" + transactionMode
				+ ", transactionDate=" + transactionDate + ", accountNo=" + accountNo + ", amount=" + amount + "]";
	}
	
}
