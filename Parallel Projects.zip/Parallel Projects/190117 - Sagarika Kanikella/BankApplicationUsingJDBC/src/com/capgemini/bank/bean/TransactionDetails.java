package com.capgemini.bank.bean;

import java.sql.Date;

public class TransactionDetails {

	private int transactionNo;
	private String transactionType;
	private Date transactionDate;
	private int accountNo;
	private double amount;
	public TransactionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionDetails(int transactionNo, String transactionType, Date transactionDate, int accountNo,
			double amount) {
		super();
		this.transactionNo = transactionNo;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.amount = amount;
	}
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "TransactionDetails [transactionNo=" + transactionNo + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", accountNo=" + accountNo + ", amount=" + amount + "]";
	}
	
}
