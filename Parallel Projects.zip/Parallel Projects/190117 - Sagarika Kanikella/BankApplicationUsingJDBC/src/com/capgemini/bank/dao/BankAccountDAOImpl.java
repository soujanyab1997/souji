package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bank.bean.CustomerDetails;
import com.capgemini.bank.bean.TransactionDetails;
import com.capgemini.bank.exception.BankAccountException;
import com.capgemini.bank.utility.DBConnection;

public class BankAccountDAOImpl implements BankAccountDAO {

	PreparedStatement statement;
	ResultSet set;
	int row = -1;

	@Override
	public int createBankAccount(CustomerDetails customerData, double amount) throws BankAccountException {

		int custId = 0, accountId = 0, transId = 0;
		try (Connection connection = DBConnection.getConnection()) {
			statement = connection.prepareStatement("select custidseq.NEXTVAL from dual");
			set = statement.executeQuery();
			while (set.next())
				custId = set.getInt(1);
			statement = connection.prepareStatement("select accnoseq.NEXTVAL from dual");
			set = statement.executeQuery();
			while (set.next())
				accountId = set.getInt(1);
			statement = connection.prepareStatement("select transidseq.NEXTVAL from dual");
			set = statement.executeQuery();
			while (set.next())
				transId = set.getInt(1);
			statement = connection.prepareStatement("insert into accountdetails values(?,?)");
			statement.setInt(1, accountId);
			statement.setDouble(2, amount);
			row = statement.executeUpdate();
			statement = connection.prepareStatement("insert into transactiondetails values(?,?,?,?,?)");
			statement.setInt(1, transId);
			statement.setString(2, "credit");
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			statement.setDate(3, date);
			statement.setInt(4, accountId);
			statement.setDouble(5, amount);
			row = statement.executeUpdate();
			statement = connection.prepareStatement("insert into customerdetails values(?,?,?,?,?,?,?)");
			statement.setInt(1, custId);
			statement.setString(2, customerData.getName());
			statement.setString(3, customerData.getEmail());
			statement.setString(4, customerData.getMobile());
			statement.setString(5, customerData.getAddress());
			statement.setInt(6, accountId);
			statement.setInt(7, transId);
			row = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountId;
	}

	@Override
	public double showBalance(int accountNo) throws BankAccountException {
		double balance = 0;
		try (Connection connection = DBConnection.getConnection()) {
			statement = connection.prepareStatement("select balance from accountdetails where accountno=?");
			statement.setInt(1, accountNo);
			set = statement.executeQuery();
			while (set.next())
				balance = set.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return balance;

	}

	@Override
	public List<TransactionDetails> deposit(int accountNo, double amount) throws BankAccountException {
		double balance = 0;
		int transId = 0;
		List<TransactionDetails> transactionList = new ArrayList<>();
		try (Connection connection = DBConnection.getConnection()) {
			statement = connection.prepareStatement("select balance from accountdetails where accountno=?");
			statement.setInt(1, accountNo);
			set = statement.executeQuery();
			while (set.next())
				balance = set.getInt(1);
			balance += amount;
			statement = connection.prepareStatement("select transidseq.NEXTVAL from dual");
			set = statement.executeQuery();
			while (set.next())
				transId = set.getInt(1);
			statement = connection.prepareStatement("update accountdetails set balance=? where accountno=?");
			statement.setDouble(1, balance);
			statement.setInt(2, accountNo);
			row = statement.executeUpdate();
			statement = connection.prepareStatement("insert into transactiondetails values(?,?,?,?,?)");
			statement.setInt(1, transId);
			statement.setString(2, "credit");
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			statement.setDate(3, date);
			statement.setInt(4, accountNo);
			statement.setDouble(5, amount);
			row = statement.executeUpdate();
			TransactionDetails transaction = new TransactionDetails(transId, "credit", date, accountNo, amount);
			transactionList.add(transaction);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return transactionList;

	}

	@Override
	public List<TransactionDetails> withdraw(int accountNo, double amount) throws BankAccountException {
		double balance = 0;
		int transId = 0;
		List<TransactionDetails> transactionList = new ArrayList<>();
		try (Connection connection = DBConnection.getConnection()) {
			statement = connection.prepareStatement("select balance from accountdetails where accountno=?");
			statement.setInt(1, accountNo);
			set = statement.executeQuery();
			while (set.next())
				balance = set.getInt(1);
			try
			{
				if(amount > balance)
				{
					throw new BankAccountException("Insufficient balance! Withdraw cannot be done \n");
				}
				else
					balance -= amount;
			}catch(BankAccountException n)
			{
				System.out.print(n.getMessage());
			}
			statement = connection.prepareStatement("select transidseq.NEXTVAL from dual");
			set = statement.executeQuery();
			while (set.next())
				transId = set.getInt(1);
			statement = connection.prepareStatement("update accountdetails set balance=? where accountno=?");
			statement.setDouble(1, balance);
			statement.setInt(2, accountNo);
			row = statement.executeUpdate();
			statement = connection.prepareStatement("insert into transactiondetails values(?,?,?,?,?)");
			statement.setInt(1, transId);
			statement.setString(2, "debit");
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			statement.setDate(3, date);
			statement.setInt(4, accountNo);
			statement.setDouble(5, amount);
			row = statement.executeUpdate();
			TransactionDetails transaction = new TransactionDetails(transId, "debit", date, accountNo, amount);
			transactionList.add(transaction);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return transactionList;
	}

	@Override
	public List<TransactionDetails> fundTransfer(int sourceAccount, int destinationAccount, double amount)
			throws BankAccountException {
		double sourceBalance = 0, destinationBalance = 0;
		int transId = 0, transId1 = 0;
		List<TransactionDetails> transactionList = new ArrayList<>();
		try (Connection connection = DBConnection.getConnection()) {
			statement = connection.prepareStatement("select balance from accountdetails where accountno=?");
			statement.setInt(1, sourceAccount);
			set = statement.executeQuery();
			while (set.next())
				sourceBalance = set.getInt(1);
			try
			{
				if(amount > sourceBalance)
				{
					throw new BankAccountException("Insufficient balance! Withdraw cannot be done \n");
				}
				else
					sourceBalance -= amount;
			}catch(BankAccountException n)
			{
				System.out.print(n.getMessage());
			}
			statement = connection.prepareStatement("select balance from accountdetails where accountno=?");
			statement.setInt(1, destinationAccount);
			set = statement.executeQuery();
			while (set.next())
				destinationBalance = set.getInt(1);
			destinationBalance += amount;
			statement = connection.prepareStatement("select transidseq.NEXTVAL from dual");
			set = statement.executeQuery();
			while (set.next())
				transId = set.getInt(1);
			statement = connection.prepareStatement("update accountdetails set balance=? where accountno=?");
			statement.setDouble(1, sourceBalance);
			statement.setInt(2, sourceAccount);
			row = statement.executeUpdate();
			statement = connection.prepareStatement("update accountdetails set balance=? where accountno=?");
			statement.setDouble(1, destinationBalance);
			statement.setInt(2, destinationAccount);
			row = statement.executeUpdate();
			statement = connection.prepareStatement("insert into transactiondetails values(?,?,?,?,?)");
			statement.setInt(1, transId);
			statement.setString(2, "debit");
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			statement.setDate(3, date);
			statement.setInt(4, sourceAccount);
			statement.setDouble(5, amount);
			row = statement.executeUpdate();
			TransactionDetails transaction = new TransactionDetails(transId, "debit", date, sourceAccount, amount);
			transactionList.add(transaction);
			statement = connection.prepareStatement("select transidseq.NEXTVAL from dual");
			set = statement.executeQuery();
			while (set.next())
				transId1 = set.getInt(1);
			statement = connection.prepareStatement("insert into transactiondetails values(?,?,?,?,?)");
			statement.setInt(1, transId1);
			statement.setString(2, "credit");
			long millis1 = System.currentTimeMillis();
			java.sql.Date date1 = new java.sql.Date(millis1);
			statement.setDate(3, date1);
			statement.setInt(4, destinationAccount);
			statement.setDouble(5, amount);
			row = statement.executeUpdate();
			TransactionDetails transaction1 = new TransactionDetails(transId1, "credit", date, destinationAccount,
					amount);
			transactionList.add(transaction1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transactionList;
	}

	@Override
	public List<TransactionDetails> printTransactions(int accountNo) throws BankAccountException {
		List<TransactionDetails> transactionList = new ArrayList<>();
		try (Connection connection = DBConnection.getConnection()) {
			statement = connection.prepareStatement("select * from transactiondetails where accountno=?");
			statement.setInt(1, accountNo);
			set = statement.executeQuery();
			while (set.next()) {
				TransactionDetails transaction = new TransactionDetails();
				transaction.setTransactionNo(set.getInt(1));
				transaction.setTransactionType(set.getString(2));
				transaction.setTransactionDate(set.getDate(3));
				transaction.setAccountNo(set.getInt(4));
				transaction.setAmount(set.getDouble(5));
				transactionList.add(transaction);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transactionList;
	}
}
