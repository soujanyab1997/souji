package com.capgemini.bank.dao;

import java.util.List;

import com.capgemini.bank.bean.CustomerDetails;
import com.capgemini.bank.bean.TransactionDetails;
import com.capgemini.bank.exception.BankAccountException;

public interface BankAccountDAO {

	public int createBankAccount(CustomerDetails customerData, double amount) throws BankAccountException;
	public double showBalance(int accountNo) throws BankAccountException;
	List<TransactionDetails> deposit(int accountNo, double amount) throws BankAccountException;
	List<TransactionDetails> withdraw(int accountNo,double amount) throws BankAccountException;
	List<TransactionDetails> fundTransfer(int sourceAccount,int destinationAccount,double amount) throws BankAccountException;
	List<TransactionDetails> printTransactions(int accountNo) throws BankAccountException;
}
