package com.exception;

public class FundTransferException extends Exception {
	
	String s;

	public FundTransferException(String s) {
		System.out.println(s);
	}
	
	

}
