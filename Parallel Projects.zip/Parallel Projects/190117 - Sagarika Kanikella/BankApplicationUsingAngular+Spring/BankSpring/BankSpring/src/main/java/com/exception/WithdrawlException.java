package com.exception;

public class WithdrawlException extends Exception {
	
	String s;

	public WithdrawlException(String s) {
		System.out.println(s);
	}
	
	

}
