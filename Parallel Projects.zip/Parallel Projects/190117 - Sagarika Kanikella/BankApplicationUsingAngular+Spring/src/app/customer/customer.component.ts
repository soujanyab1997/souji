import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customer :Customer= new Customer();

  constructor(private service:CustomerService) { }

  ngOnInit() {
  }

  
  addCust(data){
    alert("Account Created Successfully")
    this.customer.custName=data.custName;
    this.customer.custMobile=data.custMob;
    this.customer.custBalance=data.custBal;
    this.service.addCustomer(this.customer).subscribe(data => console.log(data), error => console.log(error));
  }
}
