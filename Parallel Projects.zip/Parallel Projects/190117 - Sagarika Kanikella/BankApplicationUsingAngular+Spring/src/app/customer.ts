export class Customer 
{
    custId:number;
    custName:string;
    custMobile:number;
    custBalance:number;
    custAccountNo:number; 
}