import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {

  Bal:number;

  constructor(private service:CustomerService) { }

  ngOnInit() {
  }

  fund(data){
    alert("Confirm To Transfer"+" "+data.accNo);
    this.service.fundTransfer(data.accNo,data.bfaccNo,data.tamt).subscribe(data=>this.Bal=data);
  }

}
