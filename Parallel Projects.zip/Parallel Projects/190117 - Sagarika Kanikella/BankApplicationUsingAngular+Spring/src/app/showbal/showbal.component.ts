import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-showbal',
  templateUrl: './showbal.component.html',
  styleUrls: ['./showbal.component.css']
})
export class ShowbalComponent implements OnInit {

  avlBal:number=0;
  customer: Customer=new Customer();

  constructor(private service:CustomerService) { }

  ngOnInit() {
  }

  showBal(data){
    
    this.service.showBalance(data.accNo).subscribe(data => this.avlBal=data);
  }
}
