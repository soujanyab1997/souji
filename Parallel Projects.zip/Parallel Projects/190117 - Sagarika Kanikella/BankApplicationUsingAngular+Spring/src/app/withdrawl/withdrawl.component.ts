import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-withdrawl',
  templateUrl: './withdrawl.component.html',
  styleUrls: ['./withdrawl.component.css']
})
export class WithdrawlComponent implements OnInit {

  finalBal:number;

  avlBal:number;

  constructor(private service:CustomerService) { }

  ngOnInit() {
  }


  withdrawl(data){
    
    this.service.withdrawl(data.custId,data.amt).subscribe(data=>this.finalBal=data);
  }

  showBal(custId){
   
    this.service.showBalance(custId).subscribe(data => this.avlBal=data);
  }

}
