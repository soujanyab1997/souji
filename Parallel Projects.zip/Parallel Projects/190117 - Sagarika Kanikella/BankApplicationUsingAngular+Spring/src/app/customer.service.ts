import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Customer } from './customer';
import { Observable } from '../../node_modules/rxjs';



@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private baseUrl = 'http://localhost:9091/bank';

  constructor(private http:HttpClient) { }

  addCustomer(customer){
    return this.http.post<Customer>(`${this.baseUrl}` + `/create`, customer);
  }

  showBalance(custId:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/show/${custId}`);
  }

  deposit(custId:number,amount:any):Observable<any>{
    return this.http.put(`${this.baseUrl}/deposit/${custId}/${amount}`,"");
  }

  withdrawl(custId:number,amount:any):Observable<any>{
    return this.http.put(`${this.baseUrl}/withdrawl/${custId}/${amount}`,"");
  }

  fundTransfer(sId:number,rId:number,amount:any):Observable<any>{
    return this.http.put(`${this.baseUrl}/transfer/${sId}/${rId}/${amount}`,"");
  }

  getAllCustomers():Observable<any>{
    return this.http.get(`${this.baseUrl}/all`)
  }
}
