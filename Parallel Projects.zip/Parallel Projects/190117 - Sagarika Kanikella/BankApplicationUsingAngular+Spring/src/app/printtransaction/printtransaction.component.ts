import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { ResourceLoader } from '../../../node_modules/@angular/compiler';
import { Customer } from '../customer';

@Component({
  selector: 'app-printtransaction',
  templateUrl: './printtransaction.component.html',
  styleUrls: ['./printtransaction.component.css']
})
export class PrinttransactionComponent implements OnInit {

  all:Customer[];

  constructor(private service:CustomerService) { }

  ngOnInit() {
    this.reloaddata();
  }


  reloaddata(){
   
    this.service.getAllCustomers().subscribe(data=>this.all=data);
  }
}
