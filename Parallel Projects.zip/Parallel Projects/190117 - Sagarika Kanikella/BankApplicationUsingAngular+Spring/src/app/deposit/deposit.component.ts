import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  totalBal:number;

  constructor(private service:CustomerService) { }

  ngOnInit() {
  }

  deposit(data){
    alert("Confirm to Add Amount"+" "+data.amt)
    this.service.deposit(data.custId,data.amt).subscribe(data=>this.totalBal=data);
  }
}
