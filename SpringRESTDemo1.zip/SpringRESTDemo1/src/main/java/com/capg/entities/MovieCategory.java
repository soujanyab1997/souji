package com.capg.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="moviecat_tb")
public class MovieCategory {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int mcId;
    private String mCatName;
    @OneToMany(mappedBy="category")
    private List<Movie> movies;
    public MovieCategory() {
        super();
    }
    public MovieCategory(String mCatName) {
        super();
        this.mCatName = mCatName;
    }
  
	public MovieCategory(String mCatName, List<Movie> movies) {
		super();
		this.mCatName = mCatName;
		this.movies = movies;
	}
	public int getMcId() {
        return mcId;
    }
   
	public List<Movie> getMovies() {
		return movies;
	}
	public void setMovies(List<Movie> movies) {
		this.movies = movies;
	}
	public void setMcId(int mcId) {
        this.mcId = mcId;
    }
    public String getmCatName() {
        return mCatName;
    }
    public void setmCatName(String mCatName) {
        this.mCatName = mCatName;
    }
    @Override
    public String toString() {
        return "MovieCategory [mcId=" + mcId + ", mCatName=" + mCatName + "]";
    }
    
    

 

    
}