package com.capg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.rest.core.annotation.RestResource;

@Entity
@Table(name="movie_tb")
public class Movie {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int mId;
    private String name;
    private String description;
    private int dailyRentalRate;
    private int stockInHand;
    @OneToOne
    @RestResource(path="movieCategories",rel="mcId")
    private MovieCategory category;
	public MovieCategory getCategory() {
		return category;
	}
	public void setCategory(MovieCategory category) {
		this.category = category;
	}
	public Movie(String name, String description, int dailyRentalRate, int stockInHand, MovieCategory category) {
		super();
		this.name = name;
		this.description = description;
		this.dailyRentalRate = dailyRentalRate;
		this.stockInHand = stockInHand;
		this.category = category;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Movie(String name, String description, int dailyRentalRate, int stockInHand) {
		super();
		this.name = name;
		this.description = description;
		this.dailyRentalRate = dailyRentalRate;
		this.stockInHand = stockInHand;
	}
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getDailyRentalRate() {
		return dailyRentalRate;
	}
	public void setDailyRentalRate(int dailyRentalRate) {
		this.dailyRentalRate = dailyRentalRate;
	}
	public int getStockInHand() {
		return stockInHand;
	}
	public void setStockInHand(int stockInHand) {
		this.stockInHand = stockInHand;
	}
	@Override
	public String toString() {
		return "Movie [mId=" + mId + ", name=" + name + ", description=" + description + ", dailyRentalRate="
				+ dailyRentalRate + ", stockInHand=" + stockInHand + ", category=" + category + "]";
	}
	
    
}
 
