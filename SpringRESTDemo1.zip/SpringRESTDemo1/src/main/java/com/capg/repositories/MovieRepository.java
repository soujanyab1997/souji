package com.capg.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import com.capg.entities.Movie;

@RepositoryRestResource
public interface MovieRepository extends JpaRepository<Movie, Integer>{
    
    
    
    Movie findByName(@Param("name") String name);
    List<Movie> findAllByName(String name);
    
    Movie findByNameAndDescription(@Param("name")String name, @Param("descr")String description);
    List<Movie> findAllByNameAndDescription(String name, String description);
    
    
    List<Movie> findAllByDailyRentalRateGreaterThan(int number);
    
    @RestResource(path="byrate")
    @Query("SELECT m from Movie m where m.stockInHand>0")
    List<Movie> getMoviesWithStockInHangZero(@Param("rate") int number);
    

 

}
 




