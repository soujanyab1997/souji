import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { ProductbrandsComponent } from './productbrands/productbrands.component';
import { RouterModule, Routes } from '../../node_modules/@angular/router';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { ProductService } from './productbrands/product.service';



const routes:Routes=[
  
  {path:'', component:HomeComponent},
  {path:'about', component:AboutComponent},
  {path:'productbrands', component:ProductbrandsComponent},
  {path:'home', component:HomeComponent}

];

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    HomeComponent,
    ProductbrandsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    FormsModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
