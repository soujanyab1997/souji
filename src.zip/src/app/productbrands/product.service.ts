import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { productDetails } from './productDetails';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }

   getProductDetails(){
    return this.http.get<productDetails[]>('/assets/productBrands.json');

 }
}
