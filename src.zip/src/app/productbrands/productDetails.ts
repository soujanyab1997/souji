export interface productDetails
{
    ProductId : any;
    Category : string;
    MainCategory : string;
    TaxTarifCode : number;
    SupplierName : string;

}