import { Component, OnInit } from '@angular/core';
import { productDetails } from './productDetails';
import { ProductService } from './product.service';

@Component({
  selector: 'app-productbrands',
  templateUrl: './productbrands.component.html',
  styleUrls: ['./productbrands.component.css']
})
export class ProductbrandsComponent implements OnInit {

  productsData:productDetails[];
  
  constructor(private prodService:ProductService) { }

  ngOnInit() {
    this.getProductDetails();
    
  }

  getProductDetails()
  {
    this.prodService.getProductDetails().subscribe(data=>this.productsData=data);
  }

}
