import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

eid :number;
ename:String;
amount:String;
discipline:String;
  constructor() { }

  ngOnInit() {
  }
emp(employeeForm)
{
  console.log("submit");
  console.log(employeeForm);
}
addEmployee(){
  alert(this.eid+" "+this.ename+" "+this.amount+" "+this.discipline)
}
}
