export interface employee{
    empId:number;
    empName:String;
    empSal:number;
    empDep:String;
    empjoiningdate:String;
}