export class Employee{
    empId:number;
   empName:String;
   empSal:String;
     empDept:String;
}