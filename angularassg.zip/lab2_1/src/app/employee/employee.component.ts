import { Component, OnInit } from '@angular/core';
import { Employee } from './Employee';
import { splitClasses } from '../../../node_modules/@angular/compiler';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {


  empId:number;
empName:String;
empSal:String;
empDept:String;

uId:number;
uName:String;
uSal:String;
uDept:String
  constructor() { }

  ngOnInit() {
  }
  emp(employeeForm)
  {
    console.log("submit");
    console.log(employeeForm);
  }
  
  employeedata:Employee[]=[
    {empId:1001,empName:"Rahul",empSal:"9000",empDept:"Java"},
    {empId:1002,empName:"Sachin",empSal:"19000",empDept:"OraApps"},
    {empId:1003,empName:"Vikash",empSal:"29000",empDept:"BI"}
    ];
    addAll(){
this.employeedata.push({
  empId:this.empId,
empName:this.empName,
empSal:this.empSal,
empDept:this.empDept
});
    }
updateOne(data){
  this.uId=data.empId,
  this.uName=data.empName,
  this.uSal=data.empSal,
  this.uDept=data.empDept

};
update(){
  for(var i=0;i<this.employeedata.length;i++)
  {
      if(this.employeedata[i].empId==this.uId)
      {
          this.employeedata[i].empId=this.uId;
          this.employeedata[i].empName=this.uName;
          this.employeedata[i].empSal=this.uSal;
          this.employeedata[i].empDept=this.uDept;
      }
  }


    }
    deleteOne(data){
for(var i=0;i<this.employeedata.length;i++)
{
  if(this.employeedata[i].empId==data.empId)
  {
    this.employeedata.splice(i,1);
  }
}
    }
}

