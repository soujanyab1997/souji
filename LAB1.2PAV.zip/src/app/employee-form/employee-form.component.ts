import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl} from '@angular/forms';

@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent implements OnInit {

  private employeeForm:FormGroup;

  constructor() { }

  ngOnInit() {

    this.employeeForm=new FormGroup({
      id : new FormControl(''),
      name : new FormControl(''),
      salary : new FormControl(''),
      department : new FormControl('')
    });
  }

  add(){
    console.log('Submit is clicked...');
    //console.log(this.employeeForm);
  }

  addEmployee(){
    alert(this.employeeForm.value.id+' '+this.employeeForm.value.name+' '+this.employeeForm.value.salary+' '+this.employeeForm.value.department)
  }

}
